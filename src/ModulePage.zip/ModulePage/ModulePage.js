import React from "react";
import Navbar from "../Navbar/Navbar";
import "./ModulePage.css";
import Mascot from './media/Mascot Yassify.png'

export default function ModulePage() {
  return (
    <div>
      <section id="screen7">
        <div className="about-section4">
          <h1>Welcome to the Future of IBACON</h1>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ flex: '1' }}>
              <img src={Mascot} alt="" style={{
                width: "60%", /* Adjust the width as needed */
                height: "auto", /* Maintain aspect ratio */
                margin: "0 auto", /* Center the container horizontally */
                padding: "1.5rem"
              }} />
            </div>
            <div style={{ flex: '1', fontSize: '25px', marginLeft: '40px', marginRight: '40px'}}>
              Embark on an exciting journey at IBACON, where knowledge meets entertainment. Discover diverse modules designed for every interest,
              from expert-led sessions to hands-on workshops. Brace yourself for gaming tournaments, awesome activities, and surprises that promise
              an unforgettable experience. Join us in shaping the future - it's more than an event; it's a celebration of learning and entertainment.
              <br /><span style={{fontSize: '4rem', lineHeight: 1.5 }}>ON SCNZ GUYZ!!!!!</span>
            </div>
          </div>
        </div>
        <Navbar />
      </section>
      <section id="screen2"></section>
      <section id="screen3"></section>
    </div>
  );
}
